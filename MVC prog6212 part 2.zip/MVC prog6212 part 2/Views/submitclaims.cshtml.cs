using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVC_prog6212_part_2.Views
{
    public class submitclaimsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
