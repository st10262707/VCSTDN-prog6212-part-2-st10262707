using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVC_prog6212_part_2.Views
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
