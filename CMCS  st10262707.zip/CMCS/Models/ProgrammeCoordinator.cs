﻿using Microsoft.Identity.Client;

namespace CMCS.Models
{
    public class ProgrammeCoordinator
    {
        public int id { get; set; }
        public string name { get; set; }
        public string Email { get; set; }

        public ProgrammeCoordinator() {}

        public ProgrammeCoordinator(int id, string name, string email)
        {
           id = id;
            name = name;
            email = email;
        }

        public string GetProgrammeCoordinatorDetails()
        {
            return $"Lecturer: {id},name: {name} email: {Email} ";

         }

        public bool ReviewClaim()
        {

        return false; 
        
        }
    
    }


       



    }
