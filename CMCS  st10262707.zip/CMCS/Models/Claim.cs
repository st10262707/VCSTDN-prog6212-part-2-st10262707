﻿using Microsoft.Identity.Client;

namespace CMCS.Models
{
    public class Claim
    {
        public int Id { get; set; }

        public int LectureId  { get; set; }

        public float HoursWorked {  get; set; }

        public float TotalAmount { get; set; }

        public bool Status { get; set; } 

        public Claim() { }
        public Lecturer lecturer 
           
        { 
            get; set;
        }

        public float CalculateTotal(float hoursWorked, float HourlyRate)
        {
            return TotalAmount = HourlyRate * hoursWorked;
        }
        public string GetLecturerDetails()
        {
            return $"LecturerId: {LectureId}, HoursWorked: {HoursWorked}, TotalAmount: {TotalAmount}";
        }
        public bool UpdateStatus()
        {
            if (Status == true)
            {
                return true;

            }

            else
            {

                return false;
            }
        }
    }
    
    
    }


