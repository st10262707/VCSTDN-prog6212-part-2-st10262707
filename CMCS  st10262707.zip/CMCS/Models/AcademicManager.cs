﻿using Microsoft.Identity.Client;

namespace CMCS.Models
{
    public class AcademicManager
    {
        public int Id { get; set; }
        public int AcademicManagerID { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public AcademicManager() { }    

        public AcademicManager(int id, int academicManagerID, string name, string email)
        {
            Id = id;
            AcademicManagerID = academicManagerID;
            Name = name;
            Email = email;
        }
        public string GenerateReport()
        {
            return "";
        }

        public bool FinalizeClaim()
        {
            return false;
        }


    }
}