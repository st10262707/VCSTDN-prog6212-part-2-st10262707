﻿namespace CMCS.Models
{
    public class HttpPostedFileBase
    {
    }
}