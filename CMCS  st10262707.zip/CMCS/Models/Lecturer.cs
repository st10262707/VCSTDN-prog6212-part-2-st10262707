﻿using Microsoft.Identity.Client;

namespace CMCS.Models
{
    public class Lecturer
    {
        public int id { get; set; }
        public int LecturerId { get; set; }

        public float hourlyrate  { get; set; }

        public string Email { get; set; }

        public Lecturer() { }

        public Lecturer(int id, int LecturerId, float hourlyrate, string email)
        {
            id = id;
            LecturerId = LecturerId;
            hourlyrate = hourlyrate;
            email = email;
        }

        public string GetLecturerDetails()
        {
            return $"Lecturer: {LecturerId}, email: {Email}, hourlyrate: {hourlyrate}, ";

        }


        public string SubmitClaim(string claim)
        {
            return claim;
        }

        public string UploadDocument()
        {
            return "";
        }

      


    }
}