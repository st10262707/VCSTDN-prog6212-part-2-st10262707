﻿using Microsoft.Identity.Client;

namespace CMCS.Models
{
    public class Document
    {
        public int Id { get; set; }
        public int ClaimId { get; set; }

        public string FilePath { get; set; }

        public DateTime UploadDate { get; set; }

        public Document() { }   
        public Document(int id, int claimId, string filePath, DateTime uploadDate)
        { 
            Id = id;
            ClaimId = claimId;
            FilePath = filePath;
            UploadDate = uploadDate;
        
        }
        public bool ValidateDocumentt()
        {
            return bool.Parse(FilePath);
        }

        

    }
}